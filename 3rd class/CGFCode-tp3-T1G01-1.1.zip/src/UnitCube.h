#ifndef UNITCUBE_H
#define UNITCUBE_H

#include "CGFobject.h"

class UnitCube: public CGFobject{
public:
	void draw();
};

#endif